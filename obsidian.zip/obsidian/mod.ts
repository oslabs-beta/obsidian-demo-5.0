import { ObsidianRouter } from './src/Obsidian.ts';
import gql from 'https://deno.land/x/oak_graphql@0.6.2/graphql-tag/index.ts';

export { ObsidianRouter, gql };
